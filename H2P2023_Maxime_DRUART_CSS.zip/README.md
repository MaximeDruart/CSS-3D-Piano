# CSS-3D-Piano
https://github.com/MaximeDruart/CSS-3D-Piano

Un piano ! En css (principalement) ! et en 3D !

# Features :
-3D
-Piano
-Rotation
-Zoom
-Site annexe en construction

# Inspi :
-google images
-les pianos
-pour l'autre site : https://www.behance.net/collection/170138351/trucs-cools

# Ressources :
-Dans le code pour la plupart (trigo css / scss)
-GSAP pour les animations